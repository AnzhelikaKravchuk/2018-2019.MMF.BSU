﻿// https://github.com/nunit/docs/wiki/TestCase-Attribute

using System;
using NUnit.Framework;
using StringExtentionLibrary;

namespace StringExtensionLibraryTests
{
    [TestFixture]
    public class StringExtentionTests
    {
        [TestCase(773738362412466175, 2, ExpectedResult = 773738362412466175)]
        [TestCase(11259375, 8, ExpectedResult = 11259375)]
        [TestCase(456675, 16, ExpectedResult = 456675)]
        public long ToDecimalConverterTest_Success(long source, int @base)
        {
            string code = Convert.ToString(source, @base);

            return code.ToDecimalConverter(new Notation(@base));
        }

        [TestCase("987", 8)]
        [TestCase("97rt", 16)]
        public void ToDecimalConverterTest_WithInvalidSymbols_ThrowArgumentException(string source, int @base)
        {
            Assert.Throws<ArgumentException>(() => source.ToDecimalConverter(new Notation(@base)));
        }

        [TestCase(null, 8)]
        [TestCase("", 16)]
        public void ToDecimalConverterTest_WithNullOrEmptyString_ThrowArgumentException(string source, int @base)
        {
            Assert.That(() => source.ToDecimalConverter(new Notation(@base)), Throws.ArgumentException);
        }
    }
}
