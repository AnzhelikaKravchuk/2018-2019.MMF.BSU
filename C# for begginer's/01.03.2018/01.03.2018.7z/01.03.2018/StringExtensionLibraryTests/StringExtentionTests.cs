﻿// https://github.com/nunit/docs/wiki/TestCase-Attribute

namespace StringExtensionLibraryTests
{
    using System;
    using NUnit.Framework;
    using StringExtentionLibrary;

    [TestFixture]
    public class StringExtentionTests
    {
        [TestCase(773738362412466175, 2, ExpectedResult = 773738362412466175)]
        //[TestCase(11259375, 8, ExpectedResult = 11259375)]
        //[TestCase(456675, 16, ExpectedResult = 456675)]
        public long ToDecimalConverterTest_ForNumber773738362412466175_In_2Base_Notation_Success(long source, int @base)
        {
            string code = Convert.ToString(source, @base);

            return code.ToDecimalConverter();
        }

        //[TestCase("0000113", 2)]
        //[TestCase("987", 8)]
        //[TestCase("97rt", 16)]
        //public void ToDecimalConverterTest_ForInvalidSymbolsInString_Throw_ArgumentException(string source, int @base)
        //{
        //    Assert.Throws<ArgumentException>(() => source.ToDecimalConverter());
        //}

        [TestCase(null, 2)]
        [TestCase("", 2)]
        public void ToDecimalConverterTest_ForNullOrEmptyString_Throw_ArgumentException(string source, int @base)
        {
            Assert.Throws<ArgumentException>(() => source.ToDecimalConverter());
        }
    }
}
