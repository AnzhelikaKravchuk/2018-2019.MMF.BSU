﻿namespace StringExtensionLibraryTests
{
    using System;

    using NUnit.Framework;

    using StringExtentionLibrary;

    [TestFixture]
    public class NotationTests
    {
        [TestCase(2, ExpectedResult = "01")]
        [TestCase(8, ExpectedResult = "01234567")]
        [TestCase(16, ExpectedResult = "0123456789ABCDEF")]
        public string AlphabetTest(int @base)
        {
            var notation = new Notation(@base);

            return notation.Alphabet;
        }

        [TestCase(17)]
        [TestCase(1)]
        [TestCase(-3)]
        public void BaseTest(int @base)
        {
            var notation = new Notation();

            Assert.Throws<ArgumentOutOfRangeException>(() => notation.Base = @base);
        }
    }
}
