﻿using System;

namespace StringExtentionLibrary
{
    public static class StringExtention
    {
        public static long ToDecimalConverter(this string source)
        {
            if (string.IsNullOrEmpty(source))
            {
                throw new ArgumentException($"Input string {nameof(source)} is null or empty!");
            }

            long number = 0, product = 1;
            int @base = 2;
            string alphabet = "01";

            string upperString = source.ToUpper();

            for (int i = source.Length - 1; i >= 0; i--)
            {
                number += product * ConvertToValue(upperString[i], alphabet);

                product *= @base;
            }

            return number;
        }

        private static int ConvertToValue(char symbol, string alphbet) => alphbet.IndexOf(symbol);
    }
}
