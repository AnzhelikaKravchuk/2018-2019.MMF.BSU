﻿using System;

namespace StringExtentionLibrary
{
    /// <summary>
    /// The string extention.
    /// </summary>
    public static class StringExtention
    {
        /// <summary>
        /// Extention method to convert string presentation number in notation with base to decimal notation.
        /// </summary>
        /// <param name="source">
        /// The source.
        /// </param>
        /// <param name="notation">
        /// The notation.
        /// </param>
        /// <returns>
        /// The <see cref="long"/>.
        /// </returns>
        /// <exception cref="ArgumentException">
        /// Throw when string is null or empty
        /// </exception>
        public static long ToDecimalConverter(this string source, Notation notation) // extention method!
        {
            if (string.IsNullOrEmpty(source))
            {
                throw new ArgumentException($"The string {nameof(source)} can not be null or empty!");
            }

            if (notation == null)
            {
                throw new ArgumentNullException($"The object {nameof(notation)} can not be null!");
            }

            long number = 0, product = 1;

            int @base = notation.Base;

            string alphabet = notation.Alphabet;

            string upperString = source.ToUpper();

            for (int i = source.Length - 1; i >= 0; i--)
            {
                // tracking OwerflowException!
                checked
                {
                    if (ConvertToValue(upperString[i], alphabet) == -1)
                    {
                        throw new ArgumentException($"Invalid symbol {source[i]} in string!");
                    }
                    else
                    {
                        number += product * ConvertToValue(upperString[i], alphabet);

                        product *= @base;
                    }
                }
            }

            return number;
        }

        /// <summary>
        /// Conver char symbol to integer value as a position in "alphabet string".
        /// </summary>
        /// <param name="symbol">
        /// The symbol.
        /// </param>
        /// <param name="alphbet">
        /// The alphbet.
        /// </param>
        /// <returns>
        /// The <see cref="int"/>.
        /// </returns>
        private static int ConvertToValue(char symbol, string alphbet) => alphbet.IndexOf(symbol);
    }
}
