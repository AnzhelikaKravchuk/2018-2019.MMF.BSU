﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Notation.cs" company="BSU">
// (c) BSU, 2018 
// </copyright>
// <summary>
//   The notation class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace StringExtentionLibrary
{
    using System;
    using System.Text;

    /// <summary>
    /// The notation class.
    /// </summary>
    public sealed class Notation
    {
        #region Constants

        /// <summary>
        /// The constraint on base of notation
        /// </summary>
        private const int Constraint = 16;

        #endregion

        #region Fields

        /// <summary>
        /// The base of notation
        /// </summary>
        private int @base;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Notation"/> class.
        /// base value set equal 10 by default
        /// </summary>
        public Notation()
        {
            this.Base = 10;
            this.Alphabet = this.StringCreation();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Notation"/> class.
        /// </summary>
        /// <param name="base">
        /// The base of notation
        /// </param>
        public Notation(int @base)
        {
            this.Base = @base;
            this.Alphabet = this.StringCreation();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the base.
        /// </summary>
        /// <exception cref="ArgumentException">
        /// Throw if value less than 1 or more than Constraint
        /// </exception>
        public int Base
        {
            get => this.@base;

            set
            {
                if (value <= 1 || value > Constraint)
                {
                    throw new ArgumentOutOfRangeException($"Base of Notation must be more then 0 and less then {Constraint}!");
                }

                this.@base = value;
            }
        }

        /// <summary>
        /// Gets the alphabet string of notation.
        /// </summary>
        public string Alphabet { get; }

        #endregion

        #region Private Methods

        /// <summary>
        /// The alphabet string creation on the basis of the base of the notation.
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        private string StringCreation()
        {
            StringBuilder sb = new StringBuilder(this.@base);

            int k = 'A';

            for (int i = 0; i < this.@base; i++)
            {
                if (i <= 9)
                {
                    sb.Append(i);
                }
                else
                {
                    sb.Append((char)k++);
                }
            }

            return sb.ToString();
        }

        #endregion
    }
}