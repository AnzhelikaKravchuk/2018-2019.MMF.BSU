﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//List<T>
namespace IntegerExtentions
{
    public static class Extentions
    {
        public static bool IsPolindrom(int number) => CreatePolindrom(number) == Math.Abs(number);

        public static int CreatePolindrom(int number)
        {
            int temp = Math.Abs(number);
            int polindrom = 0;
            while (temp != 0)
            {
                int rest = temp % 10;
                temp /= 10;
                polindrom = polindrom * 10 + rest;
            }

            //TODO
            return polindrom;
        }
    }
}
