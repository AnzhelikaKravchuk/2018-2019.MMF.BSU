﻿using System;
using IntegerExtentions;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Extentions.IsPolindrom(12321));
        }
    }
}
