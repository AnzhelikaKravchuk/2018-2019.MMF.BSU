﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using IntegerLibrary;

namespace IntegerLibrary.Tests.NUnit
{
    [TestFixture]
    public class IntegerExtensionTests
    {
        [TestCase(7, ExpectedResult = true)]
        [TestCase(11, ExpectedResult = true)]
        public bool IsSimpleNumber_True(int number)
        {
            return IntegerExtension.IsSimpleNumber(number);
        }
    }
}
