﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//using IntegerLibrary;
using static IntegerLibrary.IntegerExtension;//only start with c# 6.0

namespace IntegerLibrary.Tests
{
    [TestClass]
    public class IntegerExtensionTests
    {
        [TestMethod]
        public void IsSimpleNumber_7_IsSimple_True()
        {
            //Arrange
            int number = 7;
            bool expected = true;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected,actual);
        }

        [TestMethod]
        public void IsSimpleNumber_11_IsSimple_True()
        {
            //Arrange
            int number = 11;
            bool expected = true;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void IsSimpleNumber_30_IsSimple_False()
        {
            //Arrange
            int number = 30;
            bool expected = false;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void IsSimpleNumber_Minus30_IsSimple_Throw_ArgumentOutOfRangeException()
        {
            int number = -30;
            bool actual = IsSimpleNumber(number);
        }
    }
}
