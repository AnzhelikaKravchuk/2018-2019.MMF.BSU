﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//using IntegerLibrary;
using static IntegerLibrary.IntegerExtension;//only start with c# 6.0

namespace IntegerLibrary.Tests
{
    [TestClass]
    public class IntegerExtensionTests
    {
        public string Symbols => "zyxwvutsrqponmlkjihgfedcba!? ";

        [TestMethod]
        public void IsSimpleNumber_7_IsSimple_True()
        {
            //Arrange
            int number = 7;
            bool expected = true;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected,actual);
        }

        [TestMethod]
        public void IsSimpleNumber_11_IsSimple_True()
        {
            //Arrange
            int number = 11;
            bool expected = true;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void IsSimpleNumber_30_IsSimple_False()
        {
            //Arrange
            int number = 30;
            bool expected = false;
            //Act
            //IntegerExtension.IsSimpleNumber(number);
            bool actual = IsSimpleNumber(number);
            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void IsSimpleNumber_Minus30_IsSimple_Throw_ArgumentOutOfRangeException()
        {
            int number = -30;
            bool actual = IsSimpleNumber(number);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Switcher_InputArray_Minus12_34__1__3_Throw_ArgumentOutOfRangeException()
        {
            int[] array = {-12, 34, 1, 3};
            string actual = Switcher(array,Symbols);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void Switcher_InputArray_Null_Throw_ArgumentNullException()
        {
            int[] array = null;
            string actual = Switcher(array,Symbols);
        }

        [TestMethod]
        public void Switcher_InputArray_6_13_18_5_22_9_8_18_7_2_Return_university()
        {
            int[] array =  { 6, 13, 18, 5, 22, 9, 8, 18, 7, 2 };
            string expected = "university";

            string actual = Switcher(array,Symbols);

            Assert.AreEqual(expected,actual);
        }

        [TestMethod]
        public void Switcher_InputArray_Empty_Return_EmptyString()
        {
            int[] array = { };
            string expected = string.Empty;

            string actual = Switcher(array,Symbols);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void NextBiggerNumber_InputNumer_Minus5_Throw_ArgumentOutOfRangeException()
        {
            long number = -5;
            long actual = NextBiggerNumber(number);
        }

        [TestMethod]
        public void NextBiggerNumber_InputIncreasedNumber_Return_Minus1()
        {
            long number = 54321;
            long expected = -1;

            long actual = NextBiggerNumber(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void NextBiggerNumber_InputNotIncreasedNumber_Return_NextNumber()
        {
            long number = 123;
            long expected = 132;

            long actual = NextBiggerNumber(number);

            Assert.AreEqual(expected, actual);
        }


    }
}
