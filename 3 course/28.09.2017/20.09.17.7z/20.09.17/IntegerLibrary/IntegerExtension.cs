﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IntegerLibrary
{
    public static class IntegerExtension
    {
        public static bool IsSimpleNumber(int number)
        {
            if (number <= 1)
            {
                throw new ArgumentOutOfRangeException(nameof(number));
            }

            for (int i = 2; i <= number / 2; i++)
            {
                if (number % i == 0)
                    return false;
            }
            return true;
        }

        public static string Switcher(int[] array, string symbols)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            if (!IsArrayValid(array,symbols.Length))
            {
                throw  new ArgumentOutOfRangeException(nameof(array));
            }

            string word = string.Empty;

            for (int i = 0; i < array.Length; i++)
            {
                word = word + symbols[array[i] - 1];
            }
           
            return word;
        }

        public static long NextBiggerNumber(long number)
        {
            if (number < 0)
            {
                throw  new ArgumentOutOfRangeException(nameof(number));
            }

            if (IsNumberDecrease(number))
            {
                return -1;
            }

            string sNumber = ToSortedString(number);
            long nextNumber = ++number;
            string sNext = ToSortedString(nextNumber);
            while (sNumber != sNext)
            {
                sNext = ToSortedString(++nextNumber);
            }
            return nextNumber;
        }
        private static string ToSortedString(long number)
        {
            char[] array = number.ToString().ToCharArray();
            Array.Sort(array);
            return new string(array);
        }
        public static bool IsNumberDecrease(long number)
        {
            int prevDigit = (int)number%10;
            number = number/10;
            int nextDigit = 0;
            while (number != 0)
            {
                nextDigit = (int)number % 10;
                if (prevDigit > nextDigit)
                {
                    return false;
                }
                number = number / 10;
                prevDigit = nextDigit;
            }
            return true;
        }

        private static bool IsArrayValid(int[] array, int n)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > n || array[i] < 1)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
