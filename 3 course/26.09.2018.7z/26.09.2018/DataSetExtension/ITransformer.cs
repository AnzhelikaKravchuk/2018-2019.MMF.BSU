﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSetExtension
{
    public interface ITransformer
    {
        string TransformToString(int value);
    }


    public class Transformer : ITransformer
    {

        public string TransformToString(int value)
        {
            return value.ToString();
        }
    }

    public class TransformerToBase : ITransformer
    {
        public int Base { get; set; }

        public TransformerToBase(int @base)
        {
            Base = @base;
        }

        public string TransformToString(int value)
        {
            Notation notation = new Notation(Base);

            var temp = new StringBuilder();

            while (value != 0)
            {
                int rest = value % notation.Base;
                temp.Append(notation.Alphabet[rest]);
                value /= notation.Base;
            }

            char[] result = temp.ToString().ToCharArray();

            for (int i = 0; i < result.Length / 2 - 1; i++)
            {
                Swap(ref result[i], ref result[result.Length - i - 1]);
            }


            return result.ToString();
        }


        private static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }
    }

    public class TransformerToWord : ITransformer
    {
        public string TransformToString(int value)
        {
            string[] words = "zero one two three four five six seven eight nine minus".Split();
            StringBuilder result = new StringBuilder();
            string digitList = string.Format(CultureInfo.InvariantCulture, "{0}", value);
            foreach (char digit in digitList)
            {
                int i = "0123456789-.".IndexOf(digit);
                if (i == -1) continue;
                if (result.Length > 0) result.Append(' ');
                result.Append(words[i]);
            }
            return result.ToString();
        }
    }
}
