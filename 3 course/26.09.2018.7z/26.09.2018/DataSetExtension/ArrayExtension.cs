﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSetExtension
{
    public static class ArrayExtension
    {
        #region Public members
        public static string[] TransformArray(int[] array, ITransformer transformer)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            if (transformer == null)
            {
                throw new ArgumentNullException(nameof(transformer));
            }


            string[] result = new string[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                result[i] = transformer.TransformToString(array[i]);
            }

            return result;
        }

        public static string[] TransformToWords(int[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            string[] result = new string[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                result[i] = TransformToString(array[i]);
            }

            return result;
        }

        public static void BubbleSort(int[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            //TODO
        }

        public static void MergeSort(int[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            //TODO
        }

        public static void QuickSort(int[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            QuickSort(array, 0, array.Length - 1);
        } 
        #endregion

        #region Private members

        private static void QuickSort(int[] array, int left, int right)
        {
            if (left < right)
            {
                int pivot = Partition(array, left, right);
                QuickSort(array, left, pivot - 1);
                QuickSort(array, pivot + 1, right);
            }
        }

        private static int Partition(int[] array, int low, int high)
        {
            int pivot = array[high];

            int i = low - 1;
            for (int j = low; j < high; j++)
            {
                if (array[j] <= pivot)
                {
                    i++;
                    Swap(ref array[i], ref array[j]);
                }
            }

            Swap(ref array[i + 1], ref array[high]);

            return i + 1;
        }

        private static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }

        #endregion
    }
}
