﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataSetExtension
{
    internal sealed class Notation
    {
        private const int LowerBase = 2;
        private const int UpperBase = 16;

        private int @base;
        private string alphabet;

        public int Base
        {
            get => this.@base;
            private set
            {
                if (value < LowerBase || value > UpperBase)
                {
                    throw new ArgumentOutOfRangeException(nameof(value));
                }

                this.@base = value;
                alphabet = this.GenerateAlphabet();
            }
        }

        public string Alphabet => this.alphabet;

        //private void set_Base(int value)
        //{
        //    if (value < LowerBase || value > UpperBase)
        //    {
        //        throw new ArgumentOutOfRangeException(nameof(value));
        //    }

        //    this.@base = value;
        //    alphabet = this.GenerateAlphabet();
        //}

        //public int get_Base() => this.@base;

        //public string get_Alphabet() => this.alphabet;

        public Notation(int @base)
        {
            this.Base = @base;
        }

        private string GenerateAlphabet()
            =>"0123456789ABCDEF".Substring(0, Base);

    }
}
