#include "stdafx.h"
#include "CppUnitTest.h"
#include "MathLibrary.h"
#include <iostream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace MathLibraryTests
{		
	TEST_CLASS(MathExtensionTests)
	{
	public:
		
		TEST_METHOD(SinTylorTest_1)
		{
			//Arrange
			double tolerance = 0.000001;
			double x = 0.127;
			double expected = sin(x);

			//Act
			double actual = Math::SinTaylor(x, tolerance);

			//Assert
			Assert::IsTrue(fabs(expected - actual) < tolerance);
			//or
			Assert::AreEqual(expected, actual, tolerance, L"Test failed");
			
			//Fail assert!
			//Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(SinTylorTest_2)
		{
			double epsilon = 0.000000001;
			double x = -12.56;
			double expected = sin(x);

			double actual = Math::SinTaylor(x, epsilon);

			Assert::IsTrue(fabs(expected - actual) < epsilon);
		}

		// Verify that negative inputs throw an exception. 
		//https://msdn.microsoft.com/en-us/library/hh598953.aspx
		TEST_METHOD(SinTylorTest_3)
		{
			wchar_t message[200];
			double epsilon = -0.000000001;
			double x = -12.56;
			//double expected = sin(x);

			try
			{
				double actual = Math::SinTaylor(x, epsilon);
				//Assert::Fail(message);
			}
			catch (std::out_of_range ex)
			//catch (std::overflow_error ex)
			{
				std::cerr << "exception caught: " << ex.what() << '\n';
			}	
		}

		//etc.
	};
}