#pragma once

struct Point
{
	double x;
	double y;
	Point()
	{
		x = 0;
		y = 0;
	}
	Point(double a, double b)
	{
		x = a;
		y = b;
	}
};

class Point2D
{
public:
	Point2D()
	{
		x = 0;
		y = 0;
	}
	Point2D(double a, double b)
	{
		x = a;
		y = b;
	}
private:
	double x;
	double y;
};