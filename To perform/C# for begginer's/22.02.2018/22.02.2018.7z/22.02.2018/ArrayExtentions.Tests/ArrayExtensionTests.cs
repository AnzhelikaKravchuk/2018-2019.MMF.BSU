﻿using System;
using ArrayExtentions;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ArrayExtentions.Tests //<-Pattern named
{
    [TestClass]
    public class ArrayExtensionTests // <- Pattern named
    {
        [TestMethod]
        public void FilterNumbers_WithDigit7_Success() // <- Pattern named
        {
            //Pattern AAA (Arrange Act Assert)

            //Arrange
            int[] array = new int[] { 1, 2, 77, 7, 701 };
            int digit = 7;

            List<int> expected = new List<int>() { 77, 7, 701 };

            //Act
            List<int> actual = ArrayExtension.FilterNumbers(array, digit);

            //Assert

            for (int i = 0; i < expected.Count; i++)
            {
                Assert.AreEqual(expected[i], actual[i]);
            }

            //or (better)

            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FilterNumbers_WithDigit7_AndNegativeElementsInArray_Success() // <- Pattern named
        {
            int[] array = new int[] { 1, 2, -77, 7, -701 };
            int digit = 7;

            List<int> expected = new List<int>() { -77, 7, -701 };

            List<int> actual = ArrayExtension.FilterNumbers(array, digit);

            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void FilterNumbers_WithDigitMinus7_ArgumentOutOfRangeException() // <- Pattern named
        {
            int[] array = new int[] { 1, 2, 77, 7, 701 };
            int digit = -7;

            List<int> actual = ArrayExtension.FilterNumbers(array, digit);
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void FilterNumbers_WithNullArgument_ThrowArgumentNullException() // <- Pattern named
        {
            int[] array = null;
            int digit = 7;

            List<int> actual = ArrayExtension.FilterNumbers(array, digit);
        }

    }
}
