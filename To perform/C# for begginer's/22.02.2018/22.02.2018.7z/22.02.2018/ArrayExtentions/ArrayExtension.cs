﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ArrayExtentions
{
    public static class ArrayExtension
    {
        public static List<int> FilterNumbers(int[] source, int digit)
        {
            if (source == null)
            {
                throw new ArgumentNullException(nameof(source));
            }

            if (digit < 0 || digit > 9)
            {
                throw new ArgumentOutOfRangeException(nameof(digit));
            }

            List<int> list = new List<int>();

            for (int i = 0; i < source.Length; i++)
            {
                if (IsDigit(Math.Abs(source[i]),digit))
                {
                    list.Add(source[i]);
                }
            }

            return list;
        }

        private static bool IsDigit(int number, int digit)
        {

            while (number != 0)
            {
                int t = number % 10;

                if (t == digit)
                {
                    return true;
                }

                number /= 10;
            }

            return false;
        }
    }
}
