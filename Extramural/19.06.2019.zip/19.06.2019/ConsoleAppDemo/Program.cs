﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Queries;

namespace ConsoleAppDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> strings = new List<string>()
            {
                "one",
                "two",
                "three",
                "four",
                "five"
            };

            var filter = strings.Where(s => s.Length == 3).Select(s => s.ToUpper());

            var filterCustom = strings.CustomWhere(s => s.Length == 3);

            foreach (var item in filter)
            {
                Console.WriteLine(item);
            }

            foreach (var item in filterCustom)
            {
                Console.WriteLine(item);
            }

            strings.Add("123");
            strings.Add("456");

            foreach (var item in filter)
            {
                Console.WriteLine(item);
            }

            foreach (var item in filterCustom)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }
    }
}
