﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queries.Tests
{
    class PositivePredicate : IPredicate<int>
    {
        public bool IsMatch(int value) =>  value > 0;
    }

    class NegativePredicate : IPredicate<int>
    {
        public bool IsMatch(int value) => value < 0;
    }

    class PredicateByDigit : IPredicate<int>
    {
        private int digit;

        public PredicateByDigit(int digit)
        {
            this.digit = digit;
        }
        public bool IsMatch(int value) => value.ToString().Contains(digit.ToString());
    }

    class PredicateStringByLength : IPredicate<string>
    {
        private int length;

        public PredicateStringByLength(int length)
        {
            this.length = length;
        }

        public bool IsMatch(string value)
        {
            if (value is null)
            {
                throw new ArgumentNullException($"{nameof(value)} can not be null!");
            }

            return value.Length == length;
        }
    }
}
