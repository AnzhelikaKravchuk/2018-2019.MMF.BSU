﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Queries.Tests
{
    [TestFixture]
    public class ManipulationTests
    {
        #region Tests for Bad code
        [TestCase(new int[]{1, 23, 45, -90, 45, -36}, ExpectedResult = new int[] { 1, 23, 45, 45})]
        [TestCase(new int[] { 1, -23, 45, -90, 45, -36 }, ExpectedResult = new int[] { 1, 45, 45 })]
        [TestCase(new int[] { 1, 23, -45, -90, 45, -36 }, ExpectedResult = new int[] { 1, 23, 45})]
        [TestCase(new int[] { -1, 23, -45, -90, -45, -36 }, ExpectedResult = new int[] {23})]
        public int[] FilterByPositive_Tests(int[] array)
        {
            return Manipulation.FilterByPositive(array);
        }

        [Test]
        public void FilterByPositive_ThrowArgumentNullException_IfArrayIsEqualsNull()
        {
            Assert.Throws<ArgumentNullException>(() => Manipulation.FilterByPositive(null));
        }

        [Test]
        public void FilterByPositive_ThrowArgumentException_IfArrayIsEmpty()
        {
            Assert.Throws<ArgumentException>(() => Manipulation.FilterByPositive(new int[]{}));
        }
        #endregion

        private static IEnumerable<TestCaseData> DataCasesForIntegers
        {
            get
            {
                yield return new TestCaseData(arg1: new int[] { 1, 23, 45, -90, 45, -36 }, 
                    arg2: new PositivePredicate()).
                    Returns(new int[] { 1, 23, 45, 45 });
                yield return new TestCaseData(arg1: new int[] { 1, -23, 45, -90, 45, -36 },
                    arg2: new NegativePredicate()).
                    Returns(new int[] { -23, -90, -36 });
                yield return new TestCaseData(arg1: new int[] { 1, 23, -45, -90, 45, -36 }, 
                    arg2: new PositivePredicate()).
                    Returns(new int[] { 1, 23, 45 });
                yield return new TestCaseData(arg1: new int[] { 1, 23, -45, -90, 45, -36 },
                        arg2: new PredicateByDigit(6)).
                    Returns(new int[] { -36 });
                yield return new TestCaseData(arg1: new int[] { 1, 23, -45, -90, 45, -36 },
                        arg2: new PredicateByDigit(4)).
                    Returns(new int[] { -45, 45 });
            }
        }

        private static IEnumerable<TestCaseData> DataCasesForStrings
        {
            get
            {
                yield return new TestCaseData(arg1: new [] { "123", "Hello, world!", "123456" },
                        arg2: new PredicateStringByLength(6)).
                    Returns(new [] { "123456" });
                yield return new TestCaseData(arg1: new [] { "123", "Hello, world!", "123456", "Hello, World!" },
                        arg2: new PredicateStringByLength(13)).
                    Returns(new [] { "Hello, world!", "Hello, World!" });
            }
        }

        [TestCaseSource(nameof(DataCasesForIntegers))]
        public int[] FilterByPredicate_Tests_ForIntegers(int[] array, IPredicate<int> predicate)
        {
            return Manipulation.FilterByPredicate(array, predicate);
        }

        [TestCaseSource(nameof(DataCasesForStrings))]
        public string[] FilterByPredicate_Tests_ForStrings(string[] array, IPredicate<string> predicate)
        {
            //return Manipulation.FilterByPredicate(array, predicate);
            return array.FilterByPredicate(predicate);
        }

        private static IEnumerable<TestCaseData> DataCasesForDelegete
        {
            get
            {
                yield return new TestCaseData(arg1: new[] { "123", "Hello, world!", "123456" },
                        arg2: new Func<string, bool>(value => value.Length == 6)).
                    Returns(new[] { "123456" });
                yield return new TestCaseData(arg1: new[] { "123", "Hello, world!", "123456", "Hello, World!" },
                        arg2: new Func<string, bool>(value => value.Length == 13)).
                    Returns(new[] { "Hello, world!", "Hello, World!" });
                yield return new TestCaseData(arg1: new[] { "1", ",","-","Hello, world!", "123456" },
                        arg2: new Func<string, bool>(value => value.Length == 1)).
                    Returns(new[] { "1", ",", "-" });
                yield return new TestCaseData(arg1: new[] { "123", "Hello, world!", "123456", "Hello, World!" },
                        arg2: new Func<string, bool>(value => value.Contains("Hello"))).
                    Returns(new[] { "Hello, world!", "Hello, World!" });
            }
        }

        [TestCaseSource(nameof(DataCasesForDelegete))]
        public string[] FilterByPredicateWithDelegete_Tests_ForStrings(string[] array, Func<string,bool> predicate)
        {
            return array.CustomWhere(predicate).ToArray();
        }
    }
}
