﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queries
{
    public static class Manipulation
    {
        #region BAD CODE!
        public static int[] FilterByPositive(int[] array)
        {
            if (array is null)
            {
                throw new ArgumentNullException($"{nameof(array)} can not be null!");
            }

            if (array.Length == 0)
            {
                throw new ArgumentException($"{nameof(array)} can not be empty!");
            }

            List<int> resInts = new List<int>();

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > 0)
                {
                    resInts.Add(array[i]);
                }
            }

            return resInts.ToArray();
        }

        public static int[] FilterByNegative(int[] array)
        {
            if (array is null)
            {
                throw new ArgumentNullException($"{nameof(array)} can not be null!");
            }

            if (array.Length == 0)
            {
                throw new ArgumentException($"{nameof(array)} can not be empty!");
            }

            List<int> resInts = new List<int>();

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < 0)
                {
                    resInts.Add(array[i]);
                }
            }

            return resInts.ToArray();
        }

        // ....
        #endregion

        public static T[] FilterByPredicate<T>(this T[] array, IPredicate<T> predicate)
        {
            if (predicate is null)
            {
                throw new ArgumentNullException($"{nameof(predicate)} can not be null!");
            }

            if (array is null)
            {
                throw new ArgumentNullException($"{nameof(array)} can not be null!");
            }

            if (array.Length == 0)
            {
                throw new ArgumentException($"{nameof(array)} can not be empty!");
            }

            List<T> result = new List<T>();

            for (int i = 0; i < array.Length; i++)
            {
                if (predicate.IsMatch(array[i]))
                {
                    result.Add(array[i]);
                }
            }

            return result.ToArray();
        }

        public static IEnumerable<T> CustomWhere<T>(this IEnumerable<T> array, Func<T, bool> predicate)
        {
            if (predicate is null)
            {
                throw new ArgumentNullException($"{nameof(predicate)} can not be null!");
            }

            if (array is null)
            {
                throw new ArgumentNullException($"{nameof(array)} can not be null!");
            }

            IEnumerable<T> CustomWhereCore()
            {
                foreach (var item in array)
                {
                    if (predicate.Invoke(item))
                    {
                        yield return item;
                    }
                }
               
            }

            return CustomWhereCore();
        }
    }
}