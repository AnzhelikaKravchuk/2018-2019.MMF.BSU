﻿namespace Logic
{
    public static class NumberManipulation
    {
        public static void Swap<T>(ref T lhs, ref T rhs)
        {
            T t = lhs;
            lhs = rhs;
            rhs = t;
        }
    }
}
