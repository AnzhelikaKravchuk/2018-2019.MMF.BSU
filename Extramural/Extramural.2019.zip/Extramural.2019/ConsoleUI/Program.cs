﻿using System;
using Logic;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter b:");
            int b = int.Parse(Console.ReadLine());

            Console.Clear();
            Console.WriteLine($"First number: {a}");
            Console.WriteLine($"First number: {b}");

            NumberManipulation.Swap(ref a, ref b);

            Console.WriteLine($"First number: {a}");
            Console.WriteLine($"First number: {b}");

            Console.ReadKey();
        }
    }
}
