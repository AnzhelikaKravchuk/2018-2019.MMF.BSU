﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Logic;

namespace WebApplicationUI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult SwapDemo()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SwapDemo(int firstNumber, int secondNumber)
        {
            ViewBag.Before = $"First number: {firstNumber}. Second Number: {secondNumber}";

            NumberManipulation.Swap(ref firstNumber, ref secondNumber);

            ViewBag.After = $"First number: {firstNumber}. Second Number: {secondNumber}";

            return View("Swap");
        }

    }
}